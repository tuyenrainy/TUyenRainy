﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CreateCirclesWithTime
{
    public partial class CreateCircle : Form
    {
        public CreateCircle()
        {
            InitializeComponent();
        }
        bool bat = false;
        bool Mau = false;
        //
        private void btnClick_Click(object sender, EventArgs e)
        {
            if (!bat)
            {
                TimeTick.Start();
                bat = true;
            }
            else
            {
                TimeTick.Stop();
                bat = false;
            }

        }
        public void MyCreateCircle(Graphics g, int x, int y, int w, int h)
        {
            int Mul = 4;
            //chane color
            if (70 - x == 0)
                if (Mau)
                    Mau = false;
                else
                    Mau = true;
            //pen
            Pen p = new Pen(Color.Red,(float)1.5);

            //draw with red pen 
            if (!Mau)
                g.DrawEllipse(Pens.Red, x * Mul, y * Mul, w * Mul, h * Mul);
            else//blue pen
                g.DrawEllipse(Pens.Blue, x * Mul, y * Mul, w * Mul, h * Mul);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //create new graphics
            Graphics g = CreateGraphics();
            //get second of time current
            int Sec = System.DateTime.Now.Second;
            //
            

            //set text of button is second
            btnClick.Text = Sec.ToString();
            //slove 
            int a = 1;
            int x = 70;
            int y = 70;
            int w = 2 * a;
            int h = 2 * a;
            //draw circle
            MyCreateCircle(g, x - Sec, y - Sec, 2 * (a + Sec), 2 * (a + Sec));

        }
    }
}
